package com.example.retrofitexample

data class DataModel(
    val id:Int,
    val death:String,
    val cause:String,
    val responsible:String,
    val last_words:String,
    val season:Int,
    val episode:Int,
    val number_of_deaths:Int)
