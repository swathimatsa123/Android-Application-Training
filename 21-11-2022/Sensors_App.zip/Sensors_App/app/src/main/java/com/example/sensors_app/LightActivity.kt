package com.example.sensors_app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle

import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class LightActivity : AppCompatActivity(), SensorEventListener {
    //set instances for the sensorManager, light sensor, and textViews
    private var sensorManager: SensorManager? = null
    private var lightSensor: Sensor? = null
    private var lightSensorText: TextView? = null
    override fun onSensorChanged(sensorEvent: SensorEvent) {

        //retrieve the current value of the light sensor
        val currentValue = sensorEvent.values[0]

        //display the retrieved values onto the textView
        lightSensorText!!.text = resources.getString(R.string.light_text, currentValue)
    }

    override fun onAccuracyChanged(sensor: Sensor, i: Int) {

        //ambient light sensor does not report accuracy changes
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_light)

        //retrieve widgets
        lightSensorText = findViewById(R.id.lightSensorText)

        //define instances
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        lightSensor = sensorManager!!.getDefaultSensor(Sensor.TYPE_LIGHT)
    }

    //register the listener once the activity starts
    override fun onStart() {
        super.onStart()
        if (lightSensor != null) {
            sensorManager!!.registerListener(this, lightSensor, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    //stop the sensor when the activity stops to reduce battery usage
    override fun onStop() {
        super.onStop()
        sensorManager!!.unregisterListener(this)
    }
}