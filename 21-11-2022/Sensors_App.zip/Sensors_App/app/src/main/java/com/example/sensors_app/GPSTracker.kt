package com.example.sensors_app

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.widget.Toast
import androidx.core.content.ContextCompat


//this class does not have an .xml file since it's more of a helper class
//for the GPSActivity. ALl the permission asking and checking logic will be
//in this class

//this class does not have an .xml file since it's more of a helper class
//for the GPSActivity. ALl the permission asking and checking logic will be
//in this class
//implement locationListener
class GPSTracker(  //display a toast message that asks the use to enable location permissions//display a toast message that
// asks the use to enable location permissions
    private val context: Context
) : LocationListener {

    //if locationManager is enabled, get last known location from the device
    //set location class to ask for location permission
    val location: Location?
        get() {
            if (ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_FINE_LOCATION
                )
                != PackageManager.PERMISSION_GRANTED
            ) {

                //display a toast message that asks the use to enable location permissions
                Toast.makeText(context, "Please enable location to continue", Toast.LENGTH_LONG)
                    .show()
            }
            val locationManager =
                context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val isEnabled = locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER)

            //if locationManager is enabled, get last known location from the device
            if (isEnabled) {
                locationManager.requestLocationUpdates(
                    LocationManager.GPS_PROVIDER,
                    5000,
                    10f,
                    this
                )
                return locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
            } else {

                //display a toast message that asks the use to enable location permissions
                Toast.makeText(context, "Please enable location to continue", Toast.LENGTH_LONG)
                    .show()
            }
            return null
        }

    //set mandatory LocationListener() methods here
    override fun onLocationChanged(location: Location) {}
    override fun onStatusChanged(s: String, i: Int, bundle: Bundle) {}
    override fun onProviderEnabled(s: String) {}
    override fun onProviderDisabled(s: String) {}
}
