package com.example.sensors_app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class ProximityActivity : AppCompatActivity(), SensorEventListener {
    private var sensorManager: SensorManager? = null
    private var proximitySensor: Sensor? = null
    private var proximitySensorText: TextView? = null
    override fun onSensorChanged(sensorEvent: SensorEvent) {

        //retrieve the current value of the proximity sensor
        val currentValue = sensorEvent.values[0]

        //display the retrieved value onto the textView
        proximitySensorText!!.text = resources.getString(R.string.proximity_text, currentValue)
    }

    override fun onAccuracyChanged(sensor: Sensor, i: Int) {

        //proximity sensor does not report accuracy changes
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_proximity)

        //retrieve widget
        proximitySensorText = findViewById(R.id.proximityText)

        //define instances
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        proximitySensor = sensorManager!!.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    }

    //register the listener once the activity starts
    override fun onStart() {
        super.onStart()
        if (proximitySensor != null) {
            sensorManager!!.registerListener(
                this,
                proximitySensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    //stop the sensor when the activity stops to reduce battery usage
    override fun onStop() {
        super.onStop()
        sensorManager!!.unregisterListener(this)
    }
}