package com.example.sensors_app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class PressureActivity : AppCompatActivity(), SensorEventListener {
    private var sensorManager: SensorManager? = null
    private var pressureSensor: Sensor? = null
    private var pressureSensorText: TextView? = null
    override fun onSensorChanged(sensorEvent: SensorEvent) {

        //retrieve the current value of the pressure sensor
        val currentValue = sensorEvent.values[0]

        //display the retrieved value onto the textView
        pressureSensorText!!.text = resources.getString(R.string.pressure_text, currentValue)
    }

    override fun onAccuracyChanged(sensor: Sensor, i: Int) {

        //pressure sensor does not report accuracy changes
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pressure)

        //retrieve widget
        pressureSensorText = findViewById(R.id.pressureSensorText)

        //define instances
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        pressureSensor = sensorManager!!.getDefaultSensor(Sensor.TYPE_PRESSURE)
    }

    //register the listener once the activity starts
    override fun onStart() {
        super.onStart()
        if (pressureSensor != null) {
            sensorManager!!.registerListener(
                this,
                pressureSensor,
                SensorManager.SENSOR_DELAY_NORMAL
            )
        }
    }

    //stop the sensor when the activity stops to reduce battery usage
    override fun onStop() {
        super.onStop()
        sensorManager!!.unregisterListener(this)
    }
}
