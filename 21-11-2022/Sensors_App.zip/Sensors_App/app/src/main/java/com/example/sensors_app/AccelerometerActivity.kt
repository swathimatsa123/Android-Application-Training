package com.example.sensors_app

import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity


class AccelerometerActivity : AppCompatActivity(), SensorEventListener {
    //set instances for the sensorManager, accelerometer, and textViews
    private var sensorManager: SensorManager? = null
    private var accelerometer: Sensor? = null
    private var xValue: TextView? = null
    private var yValue: TextView? = null
    private var zValue: TextView? = null
    override fun onSensorChanged(sensorEvent: SensorEvent) {

        //get the current values of the accelerometer for each axis
        val current_xValue = sensorEvent.values[0]
        val current_yValue = sensorEvent.values[1]
        val current_zValue = sensorEvent.values[2]

        //display the current values of the  accelerometer for each axis onto the
        //textView widgets
        xValue!!.text = resources.getString(R.string.accelerometer_x_value, current_xValue)
        yValue!!.text = resources.getString(R.string.accelerometer_y_value, current_yValue)
        zValue!!.text = resources.getString(R.string.accelerometer_z_value, current_zValue)
    }

    override fun onAccuracyChanged(sensor: Sensor, i: Int) {

        //accelerometer does not report accuracy changes
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_accelerometer)

        //retrieve widgets
        xValue = findViewById(R.id.xValue)
        yValue = findViewById(R.id.yValue)
        zValue = findViewById(R.id.zValue)

        //define instances
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        accelerometer = sensorManager!!.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
    }

    //register the listener once the activity starts
    override fun onStart() {
        super.onStart()
        if (accelerometer != null) {
            sensorManager!!.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_NORMAL)
        }
    }

    //stop the sensor when the activity stops to reduce battery usage
    override fun onStop() {
        super.onStop()
        sensorManager!!.unregisterListener(this)
    }
}