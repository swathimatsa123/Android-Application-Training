package com.example.sensors_app

import android.Manifest
import android.location.Location
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat


//notice that the GPS does not require the sensorEventListener
class GPSActivity : AppCompatActivity() {
    //set instances of widgets and location request code
    private val LOCATION_REQUEST = 1
    private var GPSBtn: Button? = null
    private var latText: TextView? = null
    private var longText: TextView? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_gpsactivity)

        //retrieve widgets
        GPSBtn = findViewById(R.id.GPSBtn)
        latText = findViewById(R.id.latText)
        longText = findViewById(R.id.longText)

        //request permission for GPS access
        ActivityCompat.requestPermissions(
            this@GPSActivity, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION),
            LOCATION_REQUEST
        )

        //set listener for GPS button widget
        GPSBtn!!.setOnClickListener(View.OnClickListener {
            //get instance of GPSTracker class in order to ask the user for
            //location access
            val GPSTracker = GPSTracker(applicationContext)
            val location: Location = GPSTracker.location!!
            if (location != null) {

                //get current values for latitude and longitude
                val latValue = location.latitude
                val longValue = location.longitude

                //display the values retrieved onto the textView widgets
                latText?.setText(resources.getString(R.string.GPS_lat_value, latValue))
                longText?.setText(resources.getString(R.string.GPS_long_value, longValue))
            }
        })
    }
}