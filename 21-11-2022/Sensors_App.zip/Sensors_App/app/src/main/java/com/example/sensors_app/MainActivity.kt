package com.example.sensors_app

import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //set instance of Android's sensorManager to access sensor services
        val sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager

        //set up all button instances
        val proximityBtn = findViewById<Button>(R.id.proximityBtn)
        val accelerometerBtn = findViewById<Button>(R.id.accelerometerBtn)
        val lightBtn = findViewById<Button>(R.id.lightBtn)
        val GPSBtn = findViewById<Button>(R.id.GPSBtn)
        val magnetometerBtn = findViewById<Button>(R.id.magnetometerBtn)
        val pressureBtn = findViewById<Button>(R.id.pressureBtn)

        //add logic for each sensor where the button is disabled if that specific sensor is
        //not available on the current device. Notice that the GPS does
        //not have logic for this because all phones have GPS
        if (sensorManager.getDefaultSensor(Sensor.TYPE_PROXIMITY) != null) {

            //set listener for button
            proximityBtn.setOnClickListener { //add intent that takes use to the sensor's activity if the button pressed
                val proximityIntent = Intent(this@MainActivity, ProximityActivity::class.java)
                startActivity(proximityIntent)
            }
        } else {

            //disable button if sensor is not available
            proximityBtn.isEnabled = false
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER) != null) {

            //set listener for button
            accelerometerBtn.setOnClickListener { //add intent that takes use to the sensor's activity if the button pressed
                val accelerometerIntent =
                    Intent(this@MainActivity, AccelerometerActivity::class.java)
                startActivity(accelerometerIntent)
            }
        } else {

            //disable button if sensor is not available
            accelerometerBtn.isEnabled = false
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT) != null) {

            //set listener for button
            lightBtn.setOnClickListener { //add intent that takes use to the sensor's activity if the button pressed
                val lightIntent = Intent(this@MainActivity, LightActivity::class.java)
                startActivity(lightIntent)
            }
        } else {

            //disable button if sensor is not available
            lightBtn.isEnabled = false
        }

        //GPS does not need if/ else statement
        GPSBtn.setOnClickListener { //add intent that takes use to the sensor's activity if the button pressed
            val GPSIntent = Intent(this@MainActivity, GPSActivity::class.java)
            startActivity(GPSIntent)
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD) != null) {

            //set listener for button
            magnetometerBtn.setOnClickListener { //add intent that takes use to the sensor's activity if the button pressed
                val magnetometerIntent = Intent(this@MainActivity, MagnetoMeterActivity::class.java)
                startActivity(magnetometerIntent)
            }
        } else {

            //disable button if sensor is not available
            magnetometerBtn.isEnabled = false
        }
        if (sensorManager.getDefaultSensor(Sensor.TYPE_PRESSURE) != null) {

            //set listener for button
            pressureBtn.setOnClickListener { //add intent that takes use to the sensor's activity if the button pressed
                val pressureIntent = Intent(this@MainActivity, PressureActivity::class.java)
                startActivity(pressureIntent)
            }
        } else {

            //disable button if sensor is not available
            pressureBtn.isEnabled = false
        }
    }
}