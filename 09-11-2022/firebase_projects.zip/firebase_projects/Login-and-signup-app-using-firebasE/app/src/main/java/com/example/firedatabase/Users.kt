package com.example.firedatabase

data class Users(val name: String? = null, val username: String? = null,val pasword: String? = null){

}
