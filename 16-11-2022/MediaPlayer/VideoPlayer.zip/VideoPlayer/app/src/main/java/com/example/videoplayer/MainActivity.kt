package com.example.videoplayer



import android.content.Intent
import android.content.pm.ActivityInfo
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.GestureDetector
import android.view.GestureDetector.SimpleOnGestureListener
import android.view.MotionEvent
import android.view.View
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {
    private val TAG = "MainActivity"
    private var stopPosition = 0
    private var videoView: VideoView? = null
    private var videoPath: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        setContentView(R.layout.activity_main)
        videoView = findViewById<View>(R.id.video_view) as VideoView
        videoPath = "android.resource://" + packageName + "/" + R.raw.google_arts_and_culture
        videoView!!.setVideoURI(Uri.parse(videoPath))
        videoView!!.start()
        val gestureDetector = GestureDetector(this, gestureListener)
        videoView!!.setOnTouchListener { v, event -> gestureDetector.onTouchEvent(event) }
    }

    override fun onResume() {
        super.onResume()
        val params = intent.extras
        if (null != params) {
            Log.e(TAG, "VideoView intent stop position: $stopPosition")
            videoPath = params.getString("videoPath")
            stopPosition = params.getInt("stopPosition")
            videoView!!.seekTo(stopPosition)
            videoView!!.start()
        }
    }

    val gestureListener: SimpleOnGestureListener = object : SimpleOnGestureListener() {
        override fun onDown(event: MotionEvent): Boolean {
            return true
        }

        override fun onSingleTapUp(event: MotionEvent): Boolean {
            Log.e(TAG, "onSingleTapUp")
            return true
        }

        override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
            Log.e(TAG, "onSingleTapConfirmed")
            videoView!!.pause()
            stopPosition = videoView!!.currentPosition
            val intent = Intent(this@MainActivity, FullscreenVideoActivity::class.java)
            intent.putExtra("videoPath", videoPath)
            intent.putExtra("stopPosition", stopPosition)
            startActivity(intent)
            return true
        }

        override fun onLongPress(e: MotionEvent) {
            super.onLongPress(e)
            Log.e(TAG, "onLongPress")
        }

        override fun onDoubleTap(e: MotionEvent): Boolean {
            Log.e(TAG, "onDoubleTap")
            return super.onDoubleTap(e)
        }
    }
}