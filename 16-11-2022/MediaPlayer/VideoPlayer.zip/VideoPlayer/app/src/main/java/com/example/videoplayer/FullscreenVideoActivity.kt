package com.example.videoplayer

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.MediaController
import android.widget.VideoView


class FullscreenVideoActivity : Activity() {
    private val TAG = "FullscreenVideoActivity"
    private var stopPosition = 0
    private var videoView: VideoView? = null
    private var mc: MediaController? = null
    private var videoPath: String? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fullscreen_video)
        val params = intent.extras
        videoPath = params!!.getString("videoPath")
        stopPosition = params.getInt("stopPosition")
        mc = MediaController(this)
        videoView = findViewById<View>(R.id.fullscreen_video_view) as VideoView
        videoView!!.setMediaController(mc)
        videoView!!.setVideoURI(Uri.parse(videoPath))
        Log.e(TAG, "FullscreenVideoView intent stop position: $stopPosition")
        videoView!!.seekTo(stopPosition)
        videoView!!.start()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        videoView!!.pause()
        stopPosition = videoView!!.currentPosition
        val intent = Intent(this@FullscreenVideoActivity, MainActivity::class.java)
        intent.putExtra("videoPath", videoPath)
        intent.putExtra("stopPosition", stopPosition)
        startActivity(intent)
    }
}