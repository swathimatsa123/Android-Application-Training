# CoordinatorLayout-Example - An example project to demonstrate how to use CoordinatorLayout in Android.  

<p align="center">
    <img src="https://github.com/mishra3452/CoordinatorLayout-Example/blob/master/assets/using-coordinator-layout-in-android-banner.jpg">
</p>
<br>

## About this Project
This project contains the example of Coordinator Layout that is used in Andorid. You can read the whole blog article based on this project from [here](https://blog.mindorks.com/using-coordinator-layout-in-android).  

## Screenshots from this project

<p align="center">
  <img src="https://github.com/mishra3452/CoordinatorLayout-Example/blob/master/assets/scroll.gif" width="250" height="500">
  <img src="https://github.com/mishra3452/CoordinatorLayout-Example/blob/master/assets/enterAlways.gif" width="250" height="500">
  <img src="https://github.com/mishra3452/CoordinatorLayout-Example/blob/master/assets/enterAlwaysCollapsed.gif" width="250" height="500">
</p>
<br>

## Step by Step guide  
Reference blog for this project - [Using Coordinator Layout in Android](https://blog.mindorks.com/using-coordinator-layout-in-android)
