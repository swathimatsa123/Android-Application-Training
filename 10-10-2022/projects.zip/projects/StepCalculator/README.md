# Step Calculator

This is a simple step calculator app created for primary use.

## Introduction

This is android application created for counting the no of steps walked by user.It is made in kotlin and contains notification feature and can run in background also
means by minimizing the file user can perform other work.This is the app made in kotlin and using the tool android studio.It can run on any phone having api>26.
It contains only one activity.Notification get updated automatically and tells how many steps we walk till now.

# Screenshot

<p id="img_cont">
	<img src="/1.jpeg" width = "200" height= "350" hspace=40>
	<img src="/2.jpeg" width = "200" height= "350" hspace=40>
	<img src="/3.jpeg" width = "200" height= "350" hspace=40>
	<img src="/4.jpeg" width = "200" height= "350" hspace=40>
</p
