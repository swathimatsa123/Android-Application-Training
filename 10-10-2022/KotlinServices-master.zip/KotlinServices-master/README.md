# KotlinServices

This sample project will help you understand the major difference between two type of services in android

1. Bounded Services
2. UnBounded/Started Services

Apart from them, It explain the working of Intent Services with help example of downloading large JSON
file from APIs.

I have used Kotlin as language so that beginners can understand the new syntax as well.
