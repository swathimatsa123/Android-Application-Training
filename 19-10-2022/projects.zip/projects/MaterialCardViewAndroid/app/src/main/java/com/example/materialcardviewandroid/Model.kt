package com.example.materialcardviewandroid

data class Movie(val title: String, val desc: String, val image: String)