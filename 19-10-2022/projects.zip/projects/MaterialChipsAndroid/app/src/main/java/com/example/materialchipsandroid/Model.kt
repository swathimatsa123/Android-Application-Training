package com.example.materialchipsandroid

data class Items(val title: String, var category: String)